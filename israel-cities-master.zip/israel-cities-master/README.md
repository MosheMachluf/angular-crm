# israel-cities
List of cities in Israel
updated for 2013

source: http://www1.cbs.gov.il/ishuvim/ishuvim_main.htm

key words for search: [רשימת ישובים, רשימת ערים, קובץ ערים, קובץ ישובים,רשימת ערים בישראל]
